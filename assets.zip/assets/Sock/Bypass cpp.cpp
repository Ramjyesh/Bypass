#include <stdio.h>
#include <conio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <stdint.h>

typedef unsigned char BYTE;

int handle;
typedef char PACKAGENAME;


//---------------------------------------------------
long int get_module_base(int pid, const char *module_name)
{
	FILE *fp;
	long addr = 0;
	char *pch;
	char filename[32];
	char line[1024];
	snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
	fp = fopen(filename, "r");
	if (fp != NULL)
	{
		while (fgets(line, sizeof(line), fp))
		{
			if (strstr(line, module_name))
			{
				pch = strtok(line, "-");
				addr = strtoul(pch, NULL, 16);
				break;
			}
		}
		fclose(fp);
	}
	return addr;
}

int XERO_qword(long long int addr, long long int value) {
    pwrite64(handle, &value, 8, addr);
    return 0;
}

int XERO_dword(long int addr, int value)
{
	pwrite64(handle, &value, 4, addr);
	return 0;
}

int XERO_float(long int addr, float value)
{
	pwrite64(handle, &value, 4, addr);
	return 0;
}

 int XERO__HEX(long int addr, BYTE* hex_value, int size)
{
    pwrite64(handle, hex_value, size, addr);
    return 0;
}


void XeroHex(long int address, char* hex_value) {
    int hex_len = strlen(hex_value) / 3 +1;
    BYTE* hex_bytes = (BYTE*)malloc(hex_len * sizeof(BYTE));
    for (int i = 0; i < hex_len; i++) {
        char byte_str[3] = {hex_value[i*3], hex_value[i*3+1], '\0'};
        hex_bytes[i] = strtol(byte_str, NULL, 16);
    }
   XERO__HEX(address, hex_bytes, hex_len);
   BYTE* read_bytes = (BYTE*)malloc(hex_len * sizeof(BYTE));
    pread64(handle, read_bytes, hex_len, address);
    int is_equal = 1;
    for (int i = 0; i < hex_len; i++) {
        if (hex_bytes[i] != read_bytes[i]) {
            is_equal = 0;
            break;
        }
    }

    if (is_equal) {
        printf("Successfully wrote %d bytes to address 0x%lx\n", hex_len, address);
    } else {
        printf("Failed to write bytes to address 0x%lx\n", address);
    }

    free(hex_bytes);
    free(read_bytes);
}





int getPID(PACKAGENAME * PackageName)
{
	DIR *dir = NULL;
	struct dirent *ptr = NULL;
	FILE *fp = NULL;
	char filepath[256];
	char filetext[128];
	dir = opendir("/proc");
	if (NULL != dir)
	{
		while ((ptr = readdir(dir)) != NULL)
		{

			if ((strcmp(ptr->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
				continue;
			if (ptr->d_type != DT_DIR)
				continue;
			sprintf(filepath, "/proc/%s/cmdline", ptr->d_name);
			fp = fopen(filepath, "r");
			if (NULL != fp)
			{
				fgets(filetext, sizeof(filetext), fp);
				if (strcmp(filetext, PackageName) == 0)
				{

					break;
				}
				fclose(fp);
			}
		}
	}
	if (readdir(dir) == NULL)
	{
		return 0;
	}
	closedir(dir);
	return atoi(ptr->d_name);
}

//---------------------------------------------------

int main(int argc, char **argv)
{
	int gs;
	int ipid = getPID("com.pubg.imobile");
	char lj[64];
	sprintf(lj, "/proc/%d/mem", ipid);
	handle = open(lj, O_RDWR);
	if (handle == -1)
	{
		exit(1);
	}

	char mname[] = "libhdmpve.so";
	long int Ue4 = get_module_base(ipid, mname);
	
	char nname[] = "libanort.so";
	long int Anogs = get_module_base(ipid, nname);
	


XeroHex(Anogs + 0x81480, "63 00 00 00");
XeroHex(Anogs + 0x81488, "63 00 00 00");
XeroHex(Anogs + 0x8148c, "63 00 00 00");
XeroHex(Anogs + 0x81494, "63 00 00 00");
XeroHex(Anogs + 0x81498, "63 00 00 00");
XeroHex(Anogs + 0x814a4, "63 00 00 00");

XeroHex(Anogs + 0x814a8, "63 00 00 00");
XeroHex(Anogs + 0x814ac, "63 00 00 00");
XeroHex(Anogs + 0x814b0, "63 00 00 00");
XeroHex(Anogs + 0x814b4, "63 00 00 00");
XeroHex(Anogs + 0x814b8, "63 00 00 00");

XeroHex(Ue4 + 0x245c8, "00 80 00 80");
XeroHex(Ue4 + 0x2e5784, "00 80 00 80");
XeroHex(Ue4 + 0x2e5784, "00 80 00 80");
XeroHex(Ue4 + 0x2e59e0, "00 80 00 80");
XeroHex(Ue4 + 0x2e5a1c, "00 80 00 80");
XeroHex(Ue4 + 0x2e5a5c, "00 80 00 80");
XeroHex(Ue4 + 0x2e5ab8, "00 80 00 80");
XeroHex(Ue4 + 0x2e5b1c, "00 80 00 80");
XeroHex(Ue4 + 0x2e5b94, "00 80 00 80");
XeroHex(Ue4 + 0x2e5bd4, "00 80 00 80");

     //  XeroHex(Ue4 + 0x4C03B6 , "00 00 08 91 00 00 00 00");
   //     XeroHex(Anogs + 0x4C0BB4,"00 00 08 91 00 00 00 00");
     //   XeroHex(Anogs + 0x4C06DE,"00 00 08 91 00 00 00 00");
        


	close(handle);
	return 0;
}
